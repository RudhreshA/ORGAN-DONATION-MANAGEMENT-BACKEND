package com.example.demo.controller;

import com.example.demo.model.Hospital;
import com.example.demo.model.OrganRequest;
import com.example.demo.model.RequestStatus;
import com.example.demo.service.HospitalService;
import com.example.demo.repository.OrganRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/organ-requests")
@RequiredArgsConstructor
public class OrganRequestController {

    private final OrganRequestRepository organRequestRepository;
    private final HospitalService hospitalService;

    // Get all requests
    @GetMapping
    public List<OrganRequest> getAllRequests() {
        return organRequestRepository.findAll();
    }

    // Get single request
    @GetMapping("/{id}")
    public ResponseEntity<OrganRequest> getRequestById(@PathVariable Long id) {
        return organRequestRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Create new organ request with hospitalId
    @PostMapping
    public ResponseEntity<OrganRequest> createRequest(@RequestBody OrganRequestRequest request) {
        OrganRequest organRequest = new OrganRequest();
        organRequest.setOrganType(request.getOrganType());
        organRequest.setStatus(RequestStatus.PENDING);

        if (request.getHospitalId() != null) {
            Hospital hospital = hospitalService.getHospitalById(request.getHospitalId());
            organRequest.setHospital(hospital);
        }

        return ResponseEntity.ok(organRequestRepository.save(organRequest));
    }

    // Update full request
    @PutMapping("/{id}")
    public ResponseEntity<OrganRequest> updateRequest(@PathVariable Long id, @RequestBody OrganRequest details) {
        return organRequestRepository.findById(id).map(req -> {
            req.setOrganType(details.getOrganType());
            req.setStatus(details.getStatus());
            if(details.getHospital() != null && details.getHospital().getId() != null){
                req.setHospital(hospitalService.getHospitalById(details.getHospital().getId()));
            }
            req.setOrganBank(details.getOrganBank());
            return ResponseEntity.ok(organRequestRepository.save(req));
        }).orElse(ResponseEntity.notFound().build());
    }

    // PATCH for status only
    @PatchMapping("/{id}/status")
    public ResponseEntity<OrganRequest> updateStatus(@PathVariable Long id,
                                                     @RequestBody StatusUpdateRequest statusRequest) {
        return organRequestRepository.findById(id).map(req -> {
            req.setStatus(statusRequest.getStatus());
            return ResponseEntity.ok(organRequestRepository.save(req));
        }).orElse(ResponseEntity.notFound().build());
    }

    // Get all requests for a hospital
    @GetMapping("/hospital/{hospitalId}")
    public ResponseEntity<List<OrganRequest>> getRequestsByHospital(@PathVariable Long hospitalId) {
        Hospital hospital = hospitalService.getHospitalById(hospitalId);
        return ResponseEntity.ok(hospital.getOrganRequests());
    }

    // DTOs
    public static class StatusUpdateRequest {
        private RequestStatus status;
        public RequestStatus getStatus() { return status; }
        public void setStatus(RequestStatus status) { this.status = status; }
    }

    public static class OrganRequestRequest {
        private String organType;
        private Long hospitalId;

        public String getOrganType() { return organType; }
        public void setOrganType(String organType) { this.organType = organType; }

        public Long getHospitalId() { return hospitalId; }
        public void setHospitalId(Long hospitalId) { this.hospitalId = hospitalId; }
    }
}
