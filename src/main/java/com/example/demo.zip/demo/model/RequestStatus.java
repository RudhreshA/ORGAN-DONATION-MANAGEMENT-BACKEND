package com.example.demo.model;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}