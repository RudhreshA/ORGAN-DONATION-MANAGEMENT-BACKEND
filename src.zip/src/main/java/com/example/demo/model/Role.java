package com.example.demo.model;

public enum Role {
    ADMIN,
    DONOR,
    HOSPITAL_STAFF,
    ORGAN_BANK_STAFF
}
 