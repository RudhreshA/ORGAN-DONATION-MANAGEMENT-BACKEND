package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Hospital;
import com.example.demo.repository.HospitalRepository;

import lombok.RequiredArgsConstructor;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class HospitalService {

    @Autowired
    private final HospitalRepository hospitalRepository;

    // Create a new hospital
    public Hospital createHospital(Hospital hospital) {
        return hospitalRepository.save(hospital);
    }

    // Update existing hospital
    public Hospital updateHospital(Long id, Hospital hospitalDetails) {
        Hospital hospital = getHospitalById(id);
        hospital.setName(hospitalDetails.getName());
        hospital.setAddress(hospitalDetails.getAddress());
        hospital.setContactNumber(hospitalDetails.getContactNumber());
        return hospitalRepository.save(hospital);
    }

    // Get hospital by ID
    public Hospital getHospitalById(Long id) {
        return hospitalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Hospital not found with id: " + id));
    }

    // Get all hospitals
    public List<Hospital> getAllHospitals() {
        return hospitalRepository.findAll();
    }

    // Delete a hospital
    public void deleteHospital(Long id) {
        hospitalRepository.deleteById(id);
    }
}
